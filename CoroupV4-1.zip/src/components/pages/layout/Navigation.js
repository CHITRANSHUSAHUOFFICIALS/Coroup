import React from "react";
import { Navbar, Nav } from "react-bootstrap";
import { LinkContainer } from "react-router-bootstrap";
import logo from "../../../logo.svg";

function Navigation() {
  return (
    <div className="app__nav">
      <Navbar bg="dark" variant="dark" expand="lg">
        <LinkContainer to="/">
          <Navbar.Brand>
            <img
              alt=""
              src={logo}
              width="45"
              height="30"
              className="App-logo d-inline-block align-top"
            />{" "}
            Coroup
          </Navbar.Brand>
        </LinkContainer>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto" defaultActiveKey="/stats">
            <LinkContainer to="/stats">
              <Nav.Link>Live Stats</Nav.Link>
            </LinkContainer>
            <LinkContainer to="/managment">
              <Nav.Link>Managment</Nav.Link>
            </LinkContainer>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    </div>
  );
}

export default Navigation;
