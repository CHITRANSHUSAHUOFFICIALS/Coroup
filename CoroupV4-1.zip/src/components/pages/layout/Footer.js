import React from "react";
import { Container, Row, Col } from "react-bootstrap";
function Footer() {
  return (
    <div>
      {/* <Navbar bg="dark" variant="dark" className="footer">
        <Container>
          <Navbar.Brand>
            <ul>
              <li>Made With ❤ by:</li>
              <ul>
                <li>Nikhil Shukla</li>
                <li>Chitranshu Sahu</li>
                <li>Nikhil Meshram</li>
                <li>Pradeep Bhardwaj</li>
              </ul>
            </ul>
          </Navbar.Brand>
        </Container>
      </Navbar> */}
      {/* <Card className="footer" bg="dark" style={{color: '#fff'}}>
        <Card.Body>
            <Card.Text> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam, nulla. </Card.Text>
            <ul>
                <li>Made With ❤ :</li>
                <ul>
                    <li>Lorem.</li>
                    <li>Lorem.</li>
                    <li>Lorem.</li>
                </ul>
            </ul>
        </Card.Body>
      </Card> */}
      <div className="footer">
        <Container className="foot-info">
          <Row>
            <Col>
              <ul>
                <li>Made With ❤ by :</li>
                <ul>
                  <li>Nikhil Shukla</li>
                  <li>Chitranshu Sahu</li>
                  <li>Nikhil Meshram</li>
                  <li>Pradeep Bhardwaj</li>
                </ul>
              </ul>
            </Col>
            <Col>
                {/* <p>Social Accounts</p> */}
            </Col>
          </Row>
        </Container>
      </div>
    </div>
  );
}

export default Footer;
