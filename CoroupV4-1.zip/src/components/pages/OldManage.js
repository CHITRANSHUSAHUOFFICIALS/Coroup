import React from "react";
import { Form, Button, Card } from "react-bootstrap";
import Logo from "../../logo.svg";

function Manage() {
  return (
    <div className="container" style={{display:"flex"}}>

      <div className="container" style={{ alignContent:"center" }}>
        <Card className="log-card" style={{ alignContent: "center", width: "400px" }}>
          <Card.Img className="App-logo" variant="top" src={Logo} width="100px" height="200px" />
          <Card.Body>
            <Card.Title>Log In</Card.Title>
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" />
              </Form.Group>

              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" placeholder="Password" />
              </Form.Group>
              <Form.Group
                className="mb-3"
                controlId="formBasicCheckbox"
              ></Form.Group>
              <Button variant="primary" type="submit">
                Log In
              </Button>
            </Form>
          </Card.Body>
        </Card>
      </div>
    </div>
  );
}

export default Manage;
