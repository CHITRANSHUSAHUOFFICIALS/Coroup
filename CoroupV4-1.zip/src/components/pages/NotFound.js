import React from "react";
import NotImg from "../../NotFound.png";
function NotFound() {
  return (
    <div className="notFound">
      <h1 className="display-1">404!</h1>
      <img src={NotImg} width="200" height="200" alt="NHL"/>
      <h1 className="display-4">Page Not Found</h1>
    </div>
  );
}

export default NotFound;
