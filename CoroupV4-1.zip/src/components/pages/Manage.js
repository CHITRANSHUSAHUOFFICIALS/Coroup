import React from "react";
import "../../App.css";
import "bootstrap/dist/css/bootstrap.css";
import { Col, Row, Container } from "react-bootstrap";
import Patients from "../Patients";

function Manage() {
  return (
    <div>
      <div className="row">
        <div className="col-md-8 offset-md-2">
          <Patients></Patients>
        </div>
      </div>
    </div>
  );
}

export default Manage;
