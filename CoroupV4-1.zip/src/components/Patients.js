// import React from "react";
// import "bootstrap/dist/css/bootstrap.css";
// import { Jumbotron, Container, Row, Col } from "react-bootstrap";
// import ContactForm from "./ContactForm";
// const Contacts = () => {
//   return (
//     <div>
//       <Jumbotron fluid>
//         <Container className="display-4 text-center">
//           <h1>Contact Register</h1>
//         </Container>
//       </Jumbotron>
//       <Row>
//         <Col md="5">
//           <ContactForm />
//         </Col>
//         <Col md="7">
//           <div>List of contacts</div>
//         </Col>
//       </Row>
//     </div>
//   );
// };

// export default Contacts;

import React, { useState, useEffect } from "react";
import PatientsForm from "./PatientsForm";
import firebaseDb from "../firebase";

const Patients = () => {
  var [currentId, setCurrentId] = useState("");
  var [patientsObjects, setPatientsObjects] = useState({});

  //Once components load complete
  useEffect(() => {
    firebaseDb.child("patients").on("value", (snapshot) => {
      if (snapshot.val() != null) {
        setPatientsObjects({
          ...snapshot.val(),
        });
      }
    });
  }, []);

  // const addOrEdit = (obj) => {
  //   /*need to implement both insert
  //   and update operation*/
  // }

  const addOrEdit = (obj) => {
    if (currentId == "")
      firebaseDb.child("patients").push(obj, (err) => {
        if (err) console.log(err);
        else setCurrentId("");
      });
    else
      firebaseDb.child(`patients/${currentId}`).set(obj, (err) => {
        if (err) console.log(err);
        else setCurrentId("");
      });
  };

  //   const onDelete = (id) => {
  //     // record with given id is to be deleted.
  //   };

  const onDelete = (id) => {
    if (window.confirm("Are you sure to delete this record?")) {
      firebaseDb.child(`patients/${id}`).remove((err) => {
        if (err) console.log(err);
        else setCurrentId("");
      });
    }
  };

  return (
    <>
      <div className="jumbotron jumbotron-fluid">
        <div className="container">
          <h1 className="display-4 text-center">Patient Manager</h1>
        </div>
      </div>
      <div className="row">
        <div className="col-md-5">
          <PatientsForm
            {...{ currentId, patientsObjects, addOrEdit }}
          ></PatientsForm>
        </div>
        <div className="col-md-7">
          <table className="table table-borderless table-stripped">
            <thead className="thead-light">
              <tr>
                <th>UID</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>Email</th>
                <th>Covid Report</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(patientsObjects).map((key) => (
                <tr key={key}>
                  <td>{patientsObjects[key].id}</td>
                  <td>{patientsObjects[key].fullName}</td>
                  <td>{patientsObjects[key].mobile}</td>
                  <td>{patientsObjects[key].email}</td>
                  <td>{patientsObjects[key].covidStat}</td>
                  <td className="bg-light">
                    <a
                      className="btn text-primary"
                      onClick={() => {
                        setCurrentId(key);
                      }}
                    >
                      <i className="fas fa-pencil-alt"></i>
                    </a>
                    <a
                      className="btn text-danger"
                      onClick={() => {
                        onDelete(key);
                      }}
                    >
                      <i className="far fa-trash-alt"></i>
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default Patients;
