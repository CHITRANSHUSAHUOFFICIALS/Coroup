// import * as firebase from "firebase";

// var firebaseConfig = {
//   apiKey: "AIzaSyDz3LQVU7W-oBAXSlfYdFTtG9wMvT3SfRE",
//   authDomain: "react-crud-7f623.firebaseapp.com",
//   databaseURL: "https://react-crud-7f623-default-rtdb.firebaseio.com",
//   projectId: "react-crud-7f623",
//   storageBucket: "react-crud-7f623.appspot.com",
//   messagingSenderId: "644732285801",
//   appId: "1:644732285801:web:34285d0ceefb00c83583f8",
// };
// // Initialize Firebase
// var fireDb = firebase.initializeApp(firebaseConfig);

// export default fireDb.database().ref();

import firebase from "firebase";

var firebaseConfig = {
  /*
  replace this object with yours
  */
  apiKey: "AIzaSyDz3LQVU7W-oBAXSlfYdFTtG9wMvT3SfRE",
  authDomain: "react-crud-7f623.firebaseapp.com",
  databaseURL: "https://react-crud-7f623-default-rtdb.firebaseio.com",
  projectId: "react-crud-7f623",
  storageBucket: "react-crud-7f623.appspot.com",
  messagingSenderId: "644732285801",
  appId: "1:644732285801:web:34285d0ceefb00c83583f8",
};

// Initialize Firebase
var fireDb = firebase.initializeApp(firebaseConfig);

export default fireDb.database().ref();
