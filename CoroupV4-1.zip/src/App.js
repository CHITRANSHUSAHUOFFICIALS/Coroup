import React from "react";
import "./App.css";
import "leaflet/dist/leaflet.css";
import "bootstrap/dist/css/bootstrap.css";
import Manage from "./components/pages/Manage";
import NotFound from "./components/pages/NotFound";
import Navigation from './components/pages/layout/Navigation';
import Stats from './Stats';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Footer from "./components/pages/layout/Footer";

const App = () => {
  return (
    <Router>
      <div className="app">
        <Navigation/>
        <Switch>
          <Route exact path="/" component={Stats}/>
          <Route exact path="/stats" component={Stats}/>
          <Route exact path="/managment" component={Manage} />
          <Route component={NotFound} />
        </Switch>
        <Footer/>
      </div>
    </Router>
  );
};

export default App;
